﻿using PostgreSQL.Data;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeEventy.Data.Models
{
    [Table("report")]
    public class Report
    {

        [Column("id")]
        public int Id { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("date_of_report")]
        public DateTime DateOfReport { get; set; }

        [ForeignKey("AuthorId")]
        public int AuthorId { get; set; }

        public Account Author { get; set; }
        [ForeignKey("EventId")]
        public int EventId { get; set; }

        public Event Event { get; set; }



    }
}

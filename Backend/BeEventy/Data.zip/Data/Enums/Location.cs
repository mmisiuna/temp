﻿namespace BeEventy.Data.Enums
{
    public enum Location
    {
        OnSite = 0,
        Online = 1,
        Hybrid = 2,
    }
}

﻿namespace BeEventy.Data.Enums
{
    public enum EventType
    {
        Music = 0,
        Sport = 1,
        Entertainment = 2,
        Education = 3,
        Social = 4,
        Culture = 5,
        Buisness = 6,
        Others = 7,
    }
}

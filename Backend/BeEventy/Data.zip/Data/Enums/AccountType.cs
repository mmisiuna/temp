﻿namespace BeEventy.Data.Enums
{
    public enum AccountType
    {
        User = 0,
        Moderation = 1,
        Admin = 2,
    }
}

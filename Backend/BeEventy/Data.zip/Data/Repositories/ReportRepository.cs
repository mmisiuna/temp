﻿using BeEventy.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace BeEventy.Data.Repositories
{
    public class ReportRepository
    {
        private readonly AppDbContext _context;
        public ReportRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Report>> GetAllReportsAsync()
        {
            return await _context.Reports.ToListAsync();
        }

        //public async Task<Event> GetReportsByEventIdAsync(int eventID)
        //{
        //    //return List of report containg eventID
        //}

        //public async Task<Event> GetReportsByUserId(int userID)
        //{
        //    //return List of report containg userID
        //}
        //public async Task<Event> GetReportsByUserEmail(string userRmail)
        //{
        //    //return List of report containg userRmail
        //}
        //public async Task<Event> GetReportsByUserNick(string userNick)
        //{
        //    //return List of report containg userNick
        //}
    }
}

﻿using BeEventy.Data.Models;
using Microsoft.EntityFrameworkCore;
using PostgreSQL.Data;

namespace BeEventy.Data.Repositories
{
    public class TicketRepository
    {
        private readonly AppDbContext _context;

        public TicketRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Ticket>> GetAllTicketsAsync()
        {
            return await _context.Tickets.ToListAsync();
        }

        public async Task<List<Ticket>> GetAllTicketsByEventIdAsync(int eventID)
        {
            //return list of all ticket for event with eventID
        }

        public async Task<Ticket> GetTheCheapestTicketByEventIdAsync(int eventID)
        {
            //return TheCheapestTicketByEventId
        }
    //do other basic methods to better wor with this table
    //create method that will checking banch of ticket for current event and returnig amount of avaliable tickets
    }
}

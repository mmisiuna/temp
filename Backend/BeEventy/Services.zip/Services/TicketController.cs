﻿namespace BeEventy.Controllers
{
    public class TicketController
    {
    }
}
